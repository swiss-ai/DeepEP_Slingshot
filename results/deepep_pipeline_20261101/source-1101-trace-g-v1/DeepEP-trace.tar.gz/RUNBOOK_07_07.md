
**§3.25 update 2 (07-08 ~08:55): V2-legacy lane measured.** DeepEP V2 (d4f41e4)
DOES export the classic `deep_ep.Buffer` legacy API (user was right — sglang-
compatible signatures, implemented over NCCL-GIN, no NVSHMEM). Tested internode
with the proven GIN env (build/lib overlay + LD_PRELOAD GIN-NCCL): **same
dispatch timeout**. Meanwhile V2-ELASTIC passed at 4096 tokens tonight on the
same env. sglang-main has NO elastic path (zbal import is NPU-only; classic
Buffer everywhere). CONVERGENT PATTERN: three independent implementations of
the LEGACY internode protocol (fork+nvshmem, upstream+nvshmem, V2-legacy+GIN)
all timeout identically on this fabric, while raw transports (nvshmem put/RC/
atomics, GIN elastic, NCCL, perftest) all work. The common factor is the legacy
internode ALGORITHM (NVL-forwarding + RDMA-barrier notify protocol) x this
fabric — not any single library. NEXT-SESSION lanes reordered:
1. **sglang→ElasticBuffer adapter** (~100-200 lines: get_dispatch_layout/
   dispatch/combine shim) — rides the ONLY internode path proven here.
2. Debug the common legacy-protocol failure (notify_dispatch barrier internals;
   NVSHMEM_DEBUG/GIN traces; single-rail test NCCL_IB_HCA=mlx5_0-only to rule
   out multi-rail interaction with the legacy protocol).
3. Mentor: known-working DeepEP-legacy-internode deployment on this fabric
   family? (If nobody has one, lane 1 is the path.)
